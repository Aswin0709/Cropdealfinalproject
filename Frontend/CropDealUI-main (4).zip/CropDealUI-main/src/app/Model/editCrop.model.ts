export interface UpdateCropDto{
    CropType : string ;
    FarmerId: number;
    CropName : string ;
    CropLocation : string ;
    CropQtyAvailable : number;
    CropExpectedPrice : number;
}