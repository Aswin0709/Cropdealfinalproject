export interface AddCropDto{
    fid : number;
    CropType : string ;
    CropName : string ;
    CropLocation : string ;
    CropQtyAvailable : number;
    CropExpectedPrice : number;
}
//interface se he karo
