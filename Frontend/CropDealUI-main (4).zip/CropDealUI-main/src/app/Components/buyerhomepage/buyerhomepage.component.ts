import { Component, OnInit } from '@angular/core';
import { CropService } from 'src/app/crop.service';

@Component({
  selector: 'app-buyerhomepage',
  templateUrl: './buyerhomepage.component.html',
  styleUrls: ['./buyerhomepage.component.css']
})
export class BuyerhomepageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    
  }

}
