﻿namespace CaseStudy.Models
{
    public class Admin
    {
        public int AdminId { get; set; }
        public string Password { get; set; }
        public string Email { get; set; }
    }
}
