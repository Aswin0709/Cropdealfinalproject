namespace CaseStudy.Models
{
    public class CropType
    {
        public int CropTypeId { get; set; }
        public string TypeName { get; set; } = null!;
    }
}
