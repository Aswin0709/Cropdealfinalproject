﻿namespace CaseStudy.Dtos
{
    public class InvoiceDto
    {
        
        public int CropId { get; set; }
        public int FarmerId { get; set; }
        public int DealerId { get; set; }
        
    }
}
