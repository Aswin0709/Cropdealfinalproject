﻿namespace CaseStudy.Dtos
{
    public class LoginDto
    {
        public string role { get; set; } = null!;
        public string username { get; set; } = null!;
        public string password { get; set; } = null!;

    }
}
