﻿namespace CaseStudy.Dtos
{
    public class Tokens
    {
        public string Token { get; set; }
        public string UserId { get; set; }
        public string Role { get; set; }
    }
}
